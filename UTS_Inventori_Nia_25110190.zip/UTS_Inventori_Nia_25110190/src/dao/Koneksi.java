package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Koneksi {
    private static final String URL = "jdbc:mysql://localhost:3306/db_inventori";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null,
                    "Koneksi gagal: driver MySQL JDBC tidak ditemukan.\n"
                    + "Tambahkan library MySQL Connector/J ke proyek.",
                    "Koneksi Gagal", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Koneksi ke database db_inventori gagal.\n"
                    + "Pastikan MySQL berjalan dan skrip database sudah dijalankan.\n\n"
                    + "Detail: " + e.getMessage(),
                    "Koneksi Gagal", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }
}